import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { ObjectType, Field, Int } from '@nestjs/graphql';
import { Product } from './product.model';

@Entity()
@ObjectType()
export class Review {
@PrimaryGeneratedColumn()
@Field(() => Int)
id: number;

@Column()
@Field()
reviewText: string;

@Column()
@Field(() => Int)
rating: number;

@ManyToOne(() => Product, (product) => product.reviews, { nullable: false })
@JoinColumn({ name: 'productId' })
@Field(() => Product)
product: Product;

}