import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { ObjectType, Field, Int } from '@nestjs/graphql';
import { Product } from './product.model';

@Entity()
@ObjectType()
export class Category {
@PrimaryGeneratedColumn()
@Field(() => Int)
id: number;

@Column()
@Field()
name: string;

@OneToMany(() => Product, (product) => product.category)
@Field(() => [Product], { nullable: true })
products: Product[];
}