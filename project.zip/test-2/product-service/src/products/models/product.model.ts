import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { ObjectType, Field, Int, Float } from '@nestjs/graphql';
import { Category } from './category.model';
import { Review } from './review.model';

@Entity()
@ObjectType() // GraphQL decorator
export class Product {
@PrimaryGeneratedColumn()
@Field(() => Int)
id: number;

@Column()
@Field()
name: string;

@Column()
@Field()
description: string;

@Column()
@Field(() => Float)
price: number;

@Column({ default: true })
@Field()
isAvailable: boolean;

@ManyToOne(() => Category, (category) => category.products, { nullable: false })
@JoinColumn({ name: 'categoryId' })
@Field(() => Category)
category: Category;

@OneToMany(() => Review, (review) => review.product)
@Field(() => [Review], { nullable: true })
reviews: Review[];
}