import { Injectable } from '@nestjs/common';
// import { NewRecipeInput } from './dto/new-recipe.input';
// import { RecipesArgs } from './dto/recipes.args';
// import { Recipe } from './models/recipe.model';
import { NewProductInput } from  './dto/new-product.dto';
import { ProductsArgs } from './dto/products.args.dto';
import { Product } from './models/product.model'

@Injectable()
export class ProductsService {
    /**
     * MOCK
     * Put some real business logic here
     * Left for demonstration purposes
     */

    async create(data: NewProductInput): Promise<Product> {
        return {} as any;
    }

    async findOneById(id: string): Promise<Product> {
        return {} as any;
    }

    async findAll(productsArgs: ProductsArgs): Promise<Product[]> {
        return [] as Product[];
    }

    async remove(id: string): Promise<boolean> {
        return true;
    }
}
