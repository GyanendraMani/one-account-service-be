import { Module } from '@nestjs/common';
import { ProductsResolver } from './products.resolver';
import { DateScalar } from '../common/scalars/date.scalar';
import { ProductsService } from './products.service';


@Module({
  providers: [ProductsResolver, ProductsService, DateScalar]
})
export class ProductsModule { }
